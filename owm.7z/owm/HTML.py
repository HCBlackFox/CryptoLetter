SvgList = (
	'<h3><img src="svg\\\\humidity.svg" class = "svg" align="middle"></img>',
	'<h3><img src="svg\\\\gauge.svg" class = "svg" align="middle"></img>',
	'<h3><img src="svg\\\\thermometer-1-2.svg" class = "svgtemp" align="middle"></img>',
	'<h3><img src="svg\\\\wind.svg" class = "svgtemp" align="middle"></img>')

SkyList = {
	'Light Rain' : '<h3><img src="svg\\\\rain.svg" class = "svg" align="middle"></img>',
	'Sun' : '<h3><img src="svg\\\\sun.svg" class = "svg" align="middle"></img>',
	'SunCloud' : '<h3><img src="svg\\\\cloud-sun.svg" class = "svg" align="middle"></img>',
	'Moon' : '<h3><img src="svg\\\\moon.svg" class = "svg" align="middle"></img>',
	'MoonCloud' : '<h3><img src="svg\\\\cloud-moon.svg" class = "svg" align="middle"></img>'}

def GenHtml(Forecast,Param):
	z = 20
	y = 5
	i = 0
	
	if Param == 'Now':
		f = open('index.html','a')
		



		f.write('<div class="now" id="now"><h1>Now<h1><hr align="left" width="50%" size="3" color="red" />\n')
		print(Forecast)
		for x in Forecast:	
				print(x)
				
				if x[0:7] == 'Weather':
					print('work')
					if 'Rain' in x[14:len(x)]:
						

						f.write(SkyList['Light Rain'] + x + '</h3>\n\n<hr align="left" width="87%" size="3" color= #394359 />\n')
					
					
					elif 'Clouds' in x[14:len(x)]:
							f.write(SkyList['SunCloud'] + x + '</h3>\n\n<hr align="left" width="87%" size="3" color= #394359 />\n')
					elif x[14:len(x)] == 'Clear Sky':
							f.write(SkyList['Sun'] + x + '</h3>\n\n<hr align="left" width="87%" size="3" color= #394359 />\n')	
				else:
					if x[0:5] == 'Date:': 
						pass
					
					else:
						f.write(SvgList[i] + x + '</h3>\n\n<hr align="left" width="87%" size="3" color= #394359 />\n')
				
				if i < 4:
					i += 1;
				
				else:
					f.write('</div>')
					break
					
		

		

	elif Param == 'Today':
		f = open('24index.html','a')
		f.write('<div class="bottomblock transition">\n<p>\n')
		AvTemp = []
		Rain = False
		Sky = 0
		Clouds = 0
		

		q = True
		for x in Forecast:
			if x[0:5] == 'Date:':
				if q: q = False; continue;
				
				
				if x[17:19] == '00':
					break

				
				f.write('<a href="#' + x[14:19] +'"  class="bottombutton"><big>'+ x[16:19] +'</big></a>')
		
		for x in Forecast:

			if x[0:7] == 'Weather':
				try:
					print(Forecast[y+6])
				except:
					y = y - 6
				print(x[14:len(x)])
				if 'Rain' in x[14:len(x)]:
					Rain = True
					print(x[14:len(x)])
					
				
				elif int(Forecast[y+6][17:19]) <= 20 and int(Forecast[y+6][17:19]) >= 6:
					if 'Clouds' in x[14:len(x)]:
						Clouds = Clouds + 1
						
					elif x[14:len(x)] == 'Clear Sky':
						Sky = Sky + 1
						
				elif int(Forecast[y+6][17:19]) > 20 or int(Forecast[y+6][17:19]) < 6:
					if 'Clouds' in x[14:len(x)]:
						Clouds = Clouds + 1
						
					elif x[14:len(x)] == 'Clear Sky':
						Sky = Sky + 1
							

			elif x[0:5] == 'Date:':
				if x[17:19] == '00':
					break
			if int(Forecast[y+6][17:19]) <= 20 and int(Forecast[y+6][17:19]) >= 6:
				if x[0:4] == 'Temp':
					AvTemp.append(float(x[13:len(x) - 3]))
			if i < 5: i += 1;
			else:
				z = z + 20; y = y + 6; i = 0;
				
				
		i = 0
		y = 5
		z = 40
		try:
			AvTemp = sum(AvTemp)/len(AvTemp)
		except:
			AvTemp = 0.0
		f.write('<hr align="left" width="100%" size="4" color="red" /></div>\n</div><div class="Day"><h1>' + 'Today Forecast' + '<h1><hr align="left" width="50%" size="3" color="red" />')
		f.write(SvgList[2] + 'Temperature: ' + str(AvTemp) + '</h3>\n\n<hr align="left" width="87%" size="3" color= #394359 />\n')
		if Rain == True:
			f.write(SkyList['Light Rain'] + 'WeatherState: Rain' + '</h3>\n\n<hr align="left" width="87%" size="3" color= #394359 />\n')
		elif Clouds > Sky:
			if int(Forecast[y+6][17:19]) <= 20 or int(Forecast[y+6][17:19]) >= 6:
				f.write(SkyList['SunCloud'] + 'WeatherState: Clouds' + '</h3>\n\n<hr align="left" width="87%" size="3" color= #394359 />\n')
			else:
				f.write(SkyList['MoonCloud'] + 'WeatherState: Clouds' + '</h3>\n\n<hr align="left" width="87%" size="3" color= #394359 />\n')
		else:
			if int(Forecast[y+6][17:19]) > 20 or int(Forecast[y+6][17:19]) < 6:
				f.write(SkyList['Moon'] + 'WeatherState: Clear Sky' + '</h3>\n\n<hr align="left" width="87%" size="3" color= #394359 />\n')
			else:
				f.write(SkyList['Sun'] + 'WeatherState: Clear Sky' + '</h3>\n\n<hr align="left" width="87%" size="3" color= #394359 />\n')
			f.write('</div>')

		f.write('<div class="br40"><h1>' + Forecast[y + 6] + '<h1><hr align="left" width="50%" size="3" color="red" />')
		for x in Forecast:

			if x[0:7] == 'Weather':
				try:
					print(Forecast[y+6])
				except:
					y = y - 6
				print(x[14:len(x)])
				if 'Rain' in x[14:len(x)]:
					Rain = True
					print(x[14:len(x)])
					f.write(SkyList['Light Rain'] + 'WeatherState: Rain' + '</h3>\n\n<hr align="left" width="87%" size="3" color= #394359 />\n')
				
				elif int(Forecast[y+6][17:19]) <= 20 and int(Forecast[y+6][17:19]) >= 6:
					if 'Clouds' in x[14:len(x)]:
						Clouds = Clouds + 1
						f.write(SkyList['SunCloud'] + x + '</h3>\n\n<hr align="left" width="87%" size="3" color= #394359 />\n')
					elif x[14:len(x)] == 'Clear Sky':
						Sky = Sky + 1
						f.write(SkyList['Sun'] + x + '</h3>\n\n<hr align="left" width="87%" size="3" color= #394359 />\n')
				elif int(Forecast[y+6][17:19]) > 20 or int(Forecast[y+6][17:19]) < 6:
					if 'Clouds' in x[14:len(x)]:
						Clouds = Clouds + 1
						f.write(SkyList['MoonCloud'] + x + '</h3>\n\n<hr align="left" width="87%" size="3" color= #394359 />\n')
					elif x[14:len(x)] == 'Clear Sky':
						Sky = Sky + 1
						f.write(SkyList['Moon'] + x + '</h3>\n\n<hr align="left" width="87%" size="3" color= #394359 />\n')			

			elif x[0:5] == 'Date:':
				if Forecast[y+6][17:19] == '00':
					break
			
			else:

				if x[0:5] == 'Date:': pass;
				else:
					f.write(SvgList[i] + x + '</h3>\n\n<hr align="left" width="87%" size="3" color= #394359 />\n')
			
			if i < 5: i += 1;
			else:
				z = z + 20; y = y + 6; i = 0;
				
				f.write('</div>\n')
				GenCss('end',z)
				try:
					f.write('<a name="' + Forecast[y + 6][14:19] + '"></a>\n<div class="br' + str(z) + '"><h1><nobr>' + Forecast[y + 6] + '</nobr></h1><hr align="left" width="50%" size="3" color="red" />')
				except:
					pass




	
	elif Param == 'Full':
		q = True
		f = open('fullindex.html','a')
		f.write('<div class="bottomblock transition">\n<p>\n')

		for x in Forecast:
			
			if x[0:5] == 'Date:':

				f.write('<a href="#' + x[14:19] +'"  class="bottombutton"><big>'+ x[17:19] +'</big></a>')
		


	
		f.write('<hr align="left" width="100%" size="4" color="red" /></div>\n<div class="br' + str(z) + '"><h1>' + Forecast[y + 6] + '<h1><hr align="left" width="50%" size="3" color="red" />')

		GenCss('start',z)

		
		q = True
		for x in Forecast:

			if x[0:7] == 'Weather':
				try:
					print(Forecast[y+6])
				except:
					y = y - 6
				print(x[14:len(x)])
				if 'Rain' in x[14:len(x)]:
					print(x[14:len(x)])
					f.write(SkyList['Light Rain'] + 'WeatherState: Rain' + '</h3>\n\n<hr align="left" width="87%" size="3" color= #394359 />\n')
				
				elif int(Forecast[y+6][17:19]) <= 20 and int(Forecast[y+6][17:19]) >= 6:
					if 'Clouds' in x[14:len(x)]:
						f.write(SkyList['SunCloud'] + x + '</h3>\n\n<hr align="left" width="87%" size="3" color= #394359 />\n')
					elif x[14:len(x)] == 'Clear Sky':
						f.write(SkyList['Sun'] + x + '</h3>\n\n<hr align="left" width="87%" size="3" color= #394359 />\n')
				elif int(Forecast[y+6][17:19]) > 20 or int(Forecast[y+6][17:19]) < 6:
					if 'Clouds' in x[14:len(x)]:
						f.write(SkyList['MoonCloud'] + x + '</h3>\n\n<hr align="left" width="87%" size="3" color= #394359 />\n')
					elif x[14:len(x)] == 'Clear Sky':
						f.write(SkyList['Moon'] + x + '</h3>\n\n<hr align="left" width="87%" size="3" color= #394359 />\n')			

			else:

				if x[0:5] == 'Date:': pass;
				else:
					f.write(SvgList[i] + x + '</h3>\n\n<hr align="left" width="87%" size="3" color= #394359 />\n')
			
			if i < 5: i += 1;
			else:
				z = z + 20; y = y + 6; i = 0;
				
				f.write('</div>\n')
				GenCss('end',z)
				try:
					f.write('<a name="' + Forecast[y + 6][14:19] + '"></a>\n<div class="br' + str(z) + '"><h1><nobr>' + Forecast[y + 6] + '</nobr></h1><hr align="left" width="50%" size="3" color="red" />')
				except:
					pass


def GenCss(param,z):
	if param == 'start':
		css = open('css\\fullindex.css','w')
		css.write('\n.br' + '20' + ''' {
		    position: relative;
		    display: block;
		    border: 4px solid rgb(30,35,45); 
		    background: rgb(30,35,45); 
		    left: 5%;
		    top: 20%;
    		width: 60%;
    		height: auto;
		}

			''')
		css.close()

	elif param == 'end':
		css = open('css\\fullindex.css','a')
		css.write('\n.br' + str(z) + ''' {
		    position: relative;
		    display: block;
		    border: 4px solid rgb(30,35,45); 
		    background: rgb(30,35,45); 
		    left: 5%;
    		width: 60%;
    		height: auto;\n'''+ 'top:' + str(z) + '%;}')
		css.close()