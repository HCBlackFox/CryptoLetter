import requests
from HTML import GenHtml


WeatherList = []
ParamList = ('humidity','pressure','temp')
NameList = ('Humidity: ','Pressure: ','Temperature: ','WindSpeed: ','WeatherState: ','Date: ')
City = 'Kirovohrad'

def Now(City,ParamList):
	Forecast = []
	APPID = City +'&appid=27285a73655eb0ad4ca9e62fffa7d6f4'

	WeekList = requests.get('http://api.openweathermap.org/data/2.5/weather?q=' + APPID, params={'units':'metric'})
	WeekList = WeekList.json()
	
	x = 0
	Forecast.append([])
	for j in range(len(ParamList)):
	 	Forecast[x].append(WeekList['main'][ParamList[j]])
	Forecast[x].append(WeekList['wind']['speed'])
	Forecast[x].append(WeekList['weather'][0]['description'])		
	Forecast[x].append('11111111111111111111111111111')
	return Forecast



def FullForecast(City,ParamList):
	Forecast = []
	APPID = City +'&appid=27285a73655eb0ad4ca9e62fffa7d6f4'

	WeekList = requests.get('http://api.openweathermap.org/data/2.5/forecast?q=' + APPID, params={'units':'metric'})
	WeekList = WeekList.json()
	
	for x in range(len(WeekList['list'])):
		Forecast.append([])
		for j in range(len(ParamList)):
		 	Forecast[x].append(WeekList['list'][x]['main'][ParamList[j]])
		Forecast[x].append(WeekList['list'][x]['wind']['speed'])
		Forecast[x].append(WeekList['list'][x]['weather'][0]['description'])		
		Forecast[x].append(WeekList['list'][x]['dt_txt'])
	return Forecast


def Forecast(Days,Forecast):
	f = open('Template\\Template.html','r'); template = f.read(); f.close()

	if Days == 'Now': f = open('index.html','w'); f.write(template); f.close();
	elif Days == 'Today': f = open('24index.html','w'); f.write(template); f.close();
	elif Days == 'Full': f = open('fullindex.html','w'); f.write(template); f.close();
	
	for x in Forecast:
		i = 0
		for j in x:
			
			if NameList[i] == 'WeatherState: ':
					WeatherList.append(NameList[i] + j.title())
			else:
				WeatherList.append(NameList[i] + str(j))
			if i >= len(NameList): break;
			else: i = i + 1;


	return WeatherList




ForecastList = FullForecast(City,ParamList)
Now = Forecast('Now',Now(City,ParamList))
GenHtml(Forecast('Full',ForecastList),'Full')
GenHtml(Forecast('Today',ForecastList),'Today')
GenHtml(Now,'Now')
